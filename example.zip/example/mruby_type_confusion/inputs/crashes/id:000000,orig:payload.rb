NotImplementedError = String
Module.constants # raise(mrb, E_NOTIMP_ERROR, "Module.constants not implemented");
