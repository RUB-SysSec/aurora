NotImplementedError = String
Module.constants # mrb_raise(mrb, E_NOTIMP_ERROR, "Module.constants not implemented");
